#include <reg51.h>

void main()
{
	int i ;
	
	while(1)	
	{ 
		P1 =  0x05 ;   // 0000 0101 	
			
		for(i=0 ; i<300; i++ ) ; 	
		P1 =  0x0a;  // 0000 1010 
		for(i=0 ; i<300; i++ ) ; 
	}
}
/*
	P1= 0xff;
		for(i=0 ; i<300; i++ ) ; 	
		 P1= 0;
		for(i=0 ; i<300; i++ ) ; 
		*/