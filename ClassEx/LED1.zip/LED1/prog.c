#include<reg51.h>
void mydelay()
{	  int i,j;
 	for(j=0;j<2;j++){
			for (i=0;i<30000;i++);  
		}
}
void main()
{							 
 	while(1)
	{
	 	P1 = 0x00  ;   mydelay();
	   	P1 = 0xff ;	mydelay();
		
	}
}
/*
  	P1 = 0xaa; 
		for (i=0;i<30000;i++);
		P1 = 0x55;
		for (i=0;i<30000;i++);
*/