#include<reg51.h>
sbit BUT0 = P2^0; 
void mydelay( int n)
{	  int i,j;
 	for(j=0;j<n;j++){
			for (i=0;i<30000;i++){  }    // 1msec 
		}
}

void main()
{		int count=0;		 
 	while(1)					// 1 off , 0 led on
	{	
		if ( BUT0==0){
			 if (count<3)count++;
			 else { count=0;
			  	   P1 = 0xff;  //put off all LEDs
			 }
			  while( BUT0==0) ;
		}
	    if (count ==1)
		{ 
			P1 = 0x00; mydelay(4);
			P1 = 0xff; mydelay(4);
		}
		if (count ==2)
		{ 
			P1 = 0x55; mydelay(4);
			P1 = 0xaa; mydelay(4);
		}
		if (count ==3)
		{ 
			P1 = 0xcc; mydelay(4);	  //1100 1100
			P1 = ~0xcc; mydelay(4);
		}
	 
	}
}