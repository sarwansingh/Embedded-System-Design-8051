#include<reg51.h>
sbit R1 = P2^0;
sbit R2 = P2^1;
sbit R3 = P2^2;
sbit R4 = P2^3;

sbit C1=  P2^4;
sbit C2=  P2^5;
sbit C3=  P2^6;
sbit C4=  P2^7;
 
sbit RS = P3^0;
sbit E = P3^1;
void mydelay()
{		   int i;
 	for(i=0;i<3000;i++);
}
void lcd_data(char x)
{	RS = 1;	  	E=1;
	P1 =x;	mydelay();
	E=0; 	
}
void lcd_cmd(char x)
{	RS =0 ;	  	E=1;
	P1 =x;	mydelay();
	E=0; 	
}
void lcd_init()
{	  	 
		lcd_cmd(0x38);
		lcd_cmd(0x01);
		lcd_cmd(0x0e);
}
void main()
{	int n1=0, n2=0,a=0; char op =' ' ; 	 
	lcd_init();
	R1=R2=R3=R4=1;  C1=C2=C3=C4=1; 
  	while(1){
 		 R1=0; 
		 if (C1==0){ lcd_data('7') ; a=a*10+7; while(C1==0);} 
		 if (C2==0){ lcd_data('8') ; a=a*10+8;while(C2==0);} 
		 if (C3==0){ lcd_data('9') ; a=a*10+9;while(C3==0);} 
		 if (C4==0){ lcd_data('/') ; while(C4==0);	} 
		 R1=1; R2=0; 
		if (C1==0){ lcd_data('4') ; a=a*10+4;while(C1==0);} 
		if (C2==0){ lcd_data('5') ; a=a*10+5;while(C2==0);} 
		if (C3==0){ lcd_data('6') ; a=a*10+6;while(C3==0);} 
		if (C4==0){ lcd_data('x') ;	while(C4==0);} 

		R2=1; R3=0; 
		if (C1==0){ lcd_data('1') ; a=a*10+1;while(C1==0);} 
		if (C2==0){ lcd_data('2') ; a=a*10+2;while(C2==0);} 
		if (C3==0){ lcd_data('3') ; a=a*10+3;while(C3==0);} 
		if (C4==0){ lcd_data('-') ;	 op='-';n1=a; a=0;while(C4==0);} 

		 R3=1; R4=0; 
		if (C1==0){ lcd_cmd(0x01) ; while(C1==0);} 
		if (C2==0){ lcd_data('0') ; a=a*10+0;while(C2==0);} 
		if (C3==0){ lcd_data('=') ; n2=a;  a=0;
			if (op=='+')	n1=n1+n2; 
			if (op=='-')	n1=n1-n2; 		
			lcd_data((n1/100)+48); 
			lcd_data(( (n1/10)%10) +48); 			//783/10 == 78%10 ==8
			lcd_data((n1%10)+48); 
			while(C3==0);
		} 
		if (C4==0){ lcd_data('+') ;op='+'; n1=a; a=0;	while(C4==0);} 

		R1=R2=R3=R4=1; 
	}
}