#include <REG51.H> 		 // P0 is data port
// seven segments contol
sbit X1=P3^2;
sbit X2=P3^3;
sbit X3=P3^4;
sbit X4=P3^5;

#define  lcd_data_pin P0
					  
sbit rs=P3^0;
sbit en=P3^2;

 
void delay(unsigned int count){
	int i,j;	
	for(i=0;i<count;i++)		
		for(j=0;j<1275;j++);
}
void lcd_command(unsigned char comm)
{	lcd_data_pin=comm;	en=1;	rs=0;	delay(1);	en=0;}
void lcd_data(unsigned char disp)
{	lcd_data_pin=disp;	en=1;	rs=1;	delay(1);	en=0;}

void lcd_dataa(unsigned char *disp)
{	int x;	
	for(x=0;disp[x]!='\0';x++)	{	lcd_data(disp[x]);	}
}
void lcd_ini()
{	
	lcd_command(0x38); delay(5);		  // for using 8-bit 2 row LCD 
	lcd_command(0x0F); delay(5);       // for display on, cursor blinking	
	lcd_command(0x80);	delay(5);
}

///////////////////LCD code over

//char arr[10]={0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff,0xe7};
char arr[10]={'0','1' ,'2',0xcf,0xe6,0xed,0xfd,0x87,0xff,0xe7};
char sbuffer[10], ch, toggle, last_toggle;
unsigned char pos;
unsigned int rc5data;

//receive serial character from serial port
char mygetchar(void)
{
        char c;
        while(!RI);
        RI = 0;
        c  = SBUF;
        return SBUF;
}
void main()
{			//  int i,j,k ;
	P0=0x00;
	P1=0x00;
	P2=0x00;
    X1=X2=X3=X4=0;
    pos = 0;

    SCON = 0x52; // 8-bit UART mode
    TMOD = 0x20; // timer 1 mode 2 auto reload
    TH1	 = 0xfd; // 9600 8-n-1
    TR1  = 1; // run timer1
    last_toggle = -1;
	
	lcd_ini();
  	lcd_dataa("hello"); 
//	X1=1;X2=1;X3=1;	 X4=1;
//	for (i=0;i<10;i++){
//			P0=arr[i];// test
//			for (j=0;j<30;j++) for (k=0;k<30000;k++); 
//	}
    
	while(1)
    {
        ch = mygetchar(); //loop till character received
        if(ch==0x0A) // if received character is <LF> end of line, time to display
        {
                pos = 0; // buffer position reset for next reading// extract rc5 data from serial buffer to 16 bit value
                rc5data = ((sbuffer[2]-'0')<<4)|(sbuffer[3]-'0'); // convert data from ASCII to low byte
                rc5data |= (((sbuffer[0]-'0')<<4)|(sbuffer[1]-'0'))<<8; // convert data from ASCII to high byte                                                
                if((rc5data&0x0800)==0x0800) // check toggle bit from rc5 data is set
                        toggle = 1;
                 else 
                        toggle = 0;
                if(toggle!=last_toggle) // check if new key is pressed
                {
                    last_toggle = toggle; // store value for next time compare
                    switch(rc5data&0x003F) // mask other bits and compare command bytes
                    {	case 0x00:      X1=1;
 										lcd_data (arr[0]); //P0=arr[0];
										break;
                        case 0x01:      X1=1;
 										lcd_data (arr[1]); //P0=arr[1];
										break;
                        case 0x02:      X1=1;
 										lcd_data (arr[2]); //P0=arr[2];                // Key2 pressed
                                        break;
                        case 0x03:      X1=1;
 										lcd_data (arr[3]); //P0=arr[3];          // Key3 pressed
                                        break;         
						case 0x04:      X1=1;
 										P0=arr[4];                                                                                                                                   
                                        break;
                        case 0x05:      X1=1;
 										P0=arr[5];                 // Key2 pressed
                                        break;
                        case 0x06:      X1=1;
 										P0=arr[6];         // Key3 pressed
                                        break;    
						case 0x07:      X1=1;
 										P0=arr[7];                 // Key2 pressed
                                        break;
                        case 0x08:      X1=1;
 										P0=arr[8];          // Key3 pressed
                                        break;     
						case 0x09:      X1=1;
 										P0=arr[9];          // Key3 pressed
                                        break;                                                                   
                    }
                }
        }
        else
        {                             //store serial data to buffer
                sbuffer[pos] = ch;
                pos++;
        }
    } // end while
}// end main