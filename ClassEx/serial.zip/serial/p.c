#include<reg51.h>
#include<string.h>
#define DATA P0
sbit RS	=P2^7;
sbit E  =P2^6;
////////////////////////////////LCD
void ms_delay(int n) // do nothing n * 1ms 
{      int i;
     for  (  ; n>0 ; n--)
         for (i=0; i< 100 ; i++);
}     
void lcd_cmd(unsigned char value)
{   
     DATA = value; 
     RS=0;       E=1;
     ms_delay(250);  
     E=0; 
}     
void lcd_datawrite(unsigned char temp)
{   
     RS=1;     E=1;
     DATA=temp;
     ms_delay(250);
     E=0;
} 
void lcd_initialize()
{
     lcd_cmd(0x38);	ms_delay(1);  // 2 line 5x7 matrix
     lcd_cmd(0x38);	ms_delay(1);
     lcd_cmd(0x38);	ms_delay(1);
     lcd_cmd(0x0c);	ms_delay(1);  // display on cursor off
     lcd_cmd(0x01);	ms_delay(1);  // clear display screen 
     lcd_cmd(0x06);	ms_delay(1);  // shift display right 
}
void lcdstring(unsigned char *str)
{
	while(*str != '\0')lcd_datawrite(*str++);
}
////////////////////////////////LCD ends
/////////////serial 
void serial_init()
{
  SCON=0X50;
  TMOD=0X20;
  TH1=0XFD;	   // baud rate 
  TR1=1;	   // timer 1 ready
  EA=1;
  EX0=1;
  IT0=1;
  IP=0X10;
}
void send_byte(unsigned char ch)
{
	TI=0;
	SBUF=ch;
	while(!TI);	 // while(TI==0);
}
void enter()
{
	send_byte(0X0D);
	send_byte(0X0A);
}
unsigned char recv_byte()
{
	unsigned char c;     
	while(!RI);	  // while(RI==0);
	RI=0;
	c=SBUF;
	return (c);
}
void sendstring(unsigned char *str)	   //char str[]
{
	while(*str != '\0')send_byte(*str++);	 // str[i] !='\0'
}
/////////////serial ends 

void main()
{	char card1[10],vijay[]="1122334455"; int i; 
	 serial_init()	 ;
	 lcd_initialize();
	 lcdstring("Welcome st331 ! ");
	 lcd_cmd ( 0xc0);
	while(1){

		for (i=0;i<10;i++) 	card1[i]= recv_byte();
		lcdstring(card1);
	    sendstring(card1);
	}
}
