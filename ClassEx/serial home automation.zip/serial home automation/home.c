#include<reg51.h>
#define DATA P2
sbit RS	=P1^0;
sbit E  =P1^1;
sbit LED1 = P3^6;sbit LED2 = P3^7;
sbit BUT1 = P3^2;sbit BUT2 = P3^3;

////////////////////////////////LCD
void ms_delay(int n) // do nothing n * 1ms 
{      int i;
     for  (  ; n>0 ; n--)
         for (i=0; i< 100 ; i++);
}     
void lcd_cmd(unsigned char value)
{   
     DATA = value; 
     RS=0;       E=1;
     ms_delay(10);  
     E=0; 
}     
void lcd_datawrite(unsigned char temp)
{   
     RS=1;     E=1;
     DATA=temp;
     ms_delay(10);
     E=0;
} 
void lcd_initialize()
{
     lcd_cmd(0x38);	ms_delay(1);  // 2 line 5x7 matrix
     lcd_cmd(0x38);	ms_delay(1);
     lcd_cmd(0x38);	ms_delay(1);
     lcd_cmd(0x0c);	ms_delay(1);  // display on cursor off
     lcd_cmd(0x01);	ms_delay(1);  // clear display screen 
     lcd_cmd(0x06);	ms_delay(1);  // shift display right 
}
void lcdstring(unsigned char *str)
{
	while(*str != '\0')lcd_datawrite(*str++);
}
////////////////////////////////LCD ends 
/////////////serial 
void serial_init()
{
  SCON=0X50;
  TMOD=0X20;
  TH1=0XFD;	   // baud rate 
  TR1=1;	   // timer 1 ready
  EA=1;
  EX0=1;
  IT0=1;
  IP=0X10;
}
unsigned char recv_byte()
{
	unsigned char c;     
	while(!RI);	  // while(RI==0);
	RI=0;
	c=SBUF;
	return (c);
}
void send_byte(unsigned char ch)
{
	TI=0;
	SBUF=ch;
	while(!TI);	 // while(TI==0);
}
//////////////// serial ends 
 
void main()
{	int flg1 = 1;	  char opt=0; 
	LED1 = LED2= 1; 
		lcd_initialize();
		serial_init();
 	while(1){ 
		 opt  =   recv_byte();
		// send_byte(opt);
		 if (opt=='1'){ LED1 = 0; //on
		  	   lcd_cmd(0x01); // clear lcd
			   lcdstring( "LED1: on") ;
		 }
		 if (opt=='2'){ LED1 = 1; //off
		  	lcd_cmd(0x01); // clear lcd
			lcdstring( "LED1: off") ;
		 }
		 if (opt=='3') LED2 = 0; //on
		 if (opt=='4') LED2 = 1;

//		 if (BUT1==0) {
//		 	LED1= ~LED1;
//			if(LED1!=0) flg1 =1; 
//			else flg1=0; 
//				 	LED2=  LED1;   
//			
//			lcd_cmd(0x01); // clear lcd
//		   if (LED1==0) lcdstring( "LED1: off") ;
//			if (LED1==1)  lcdstring( "on") ;
//		  	while(BUT1==0) ; 	
//		 } 
//	
//		 if (BUT2==0) {
//		 	LED2= ~LED2;
//		  	while(BUT2==0) ; 	
//		 }
	}
}
