#include<reg51.h>
#define ON 0
#define OFF 1

sbit RS = P3^0;
sbit E = P3^1;

sbit READ = P3^2;
sbit WRITE = P3^3;
sbit INTR = P3^4;

sbit FAN = P3^5;

void mydelay()
{		   int i;
 	for(i=0;i<3000;i++);
}
void lcd_data(char x)
{	RS = 1;	  	E=1;
	P1 =x;	mydelay();
	E=0; 	
}
void lcd_cmd(char x)
{	RS =0 ;	  	E=1;
	P1 =x;	mydelay();
	E=0; 	
}
void lcd_init()
{	  	 
		lcd_cmd(0x38);
		lcd_cmd(0x01);
		lcd_cmd(0x0c);
}
void lcd_str(char str[])
{	 int i=0;
	 for ( i=0; str[i] != '\0' ; i++) lcd_data(	str[i]);
}
void lcd_no(int a )		 //342
{							 int x=0;
	 x =   (a/100)	 ;
	 if (x>0)  lcd_data( x +48);
	 else  lcd_data( ' ' ); 
	 x =   (a%100) /10;
	 if (x>0)  lcd_data( x +48); 
	 lcd_data( (a%10) +48); 

}
char msg1[]="Temp. cont. fan "  ;
void main()
{	 		 int a=0;
	lcd_init();
	lcd_str(msg1); 
	
	while(1)
	{  		
		INTR=1;  READ=1;   //initialize values  	
		WRITE=0;  mydelay(); WRITE=1;
		while (INTR != 0) ; //wait till INTR is not zero 
		READ = 0; 
		a=P2; 
		
		lcd_cmd(0xc0);
		lcd_no (a  ) ; 

		if (a>50) FAN = ON; 
		else FAN = OFF; 

		mydelay(); mydelay(); mydelay(); mydelay(); mydelay(); 
			 
	}
}