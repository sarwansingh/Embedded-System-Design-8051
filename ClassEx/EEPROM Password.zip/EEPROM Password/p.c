#include<reg51.h>
#include<intrins.h>  // pata karo ji 
sbit RS = P3^0;
sbit E = P3^1;
sbit scl = P3^2;
sbit sda = P3^3;
bit ack; 
void mydelay()
{		   int i;
 	for(i=0;i<30000;i++);
}
void lcd_data(char x)
{	RS = 1;	  	E=1;
	P2 =x;	mydelay();
	E=0; 	
}
void lcd_cmd(char x)
{	RS =0 ;	  	E=1;
	P2 =x;	mydelay();
	E=0; 	
}
void lcd_init()
{
 	lcd_cmd(0x38);
	lcd_cmd(0x01);
	lcd_cmd(0x0e);
}
void lcd_str(char s[])
{	int i=0;
	for (i=0;s[i] != '\0' ;i++) lcd_data(s[i]); 	
}
///////////////// i2c wala kaaam
void aknowledge()	  //acknowledge condition
{	scl=1;	_nop_();	_nop_();	scl=0;}

void start()		//start condition
{	
	sda=1;	scl=1;	
	_nop_();    _nop_();	     //No operation
 	sda=0;	scl=0;
}
void stop()			//stop condition
{	
	sda=0;	scl=1;	
	_nop_();  _nop_(); 	
	sda=1;	scl=0;
}


void send_byte(unsigned char x)
{	int i ;
	for (i=0;i<8;i++)
	{	sda = x/128;				 
		x=x<<1; 
		scl=1;		_nop_();		_nop_();	
		scl=0;	
	}  
	 ack=sda;					//reading acknowledge  
	 sda=0;
}
void write_i2c(unsigned char a)
{
 	 start();
	 send_byte(0xA0);	aknowledge();	// address of device 
	 send_byte(0x00);	aknowledge();// device location 
	 send_byte(a);		aknowledge();// write data at that location  
	 stop();  
	 if(ack==0)	  	// data written successfully 
	 {  	lcd_data('o');
			lcd_data('k');	
	 }  
	 aknowledge();
}
unsigned char read_byte()			//reading from EEPROM serially
{	unsigned char reead=0;	
	unsigned int i;	sda=1;
	for(i=0;i<8;i++)	{		
		reead=reead<<1;		
		scl=1;		_nop_();	_nop_();	
		if(sda==1)			reead++;		
		scl=0;	
	}								 //0101 0001
	sda=0;	return reead;				//Returns 8 bit data here
}					  // reead =001010001  	  =81
int  read_i2c()
{		unsigned  char j; 
	start();	
		send_byte(0xA0);	aknowledge();		//device address
		send_byte(0x00);	aknowledge();		//word address
	start();	
		send_byte(0xA1);	//device address	
		aknowledge();	
									   
	j=read_byte();	aknowledge();  	//lcd_data(j);
	stop();	return(j);
}

/////////////////// kaaam khatam
char name[] = "Do google..." ; 
void main()
{	  	int pass=251,i;  
		 lcd_init()	;
		 lcd_str("  welcome  " ) ;   	
		lcd_cmd(0x01);
	
		lcd_str(" Writing...  " ) ;   
 	    write_i2c(pass);
		 
		lcd_cmd(0xc0);
		lcd_str(" Reading...  " ) ; 
		i=read_i2c() ;

		// extracting digits  
		lcd_data(i/100+48); 
		lcd_data((i/10)%10+48);
		lcd_data(i%10+48);
	//while(1)
	//{	}

}
